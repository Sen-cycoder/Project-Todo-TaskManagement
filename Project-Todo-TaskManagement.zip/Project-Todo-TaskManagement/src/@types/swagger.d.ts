declare module 'swagger-ui-express' {
    export default function (options: any): any;
  }
  