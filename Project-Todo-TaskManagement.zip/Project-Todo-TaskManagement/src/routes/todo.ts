import express from 'express';
import {
  create,
  get,
  getById,
  update,
  remove,
} from '../controllers/todo';
import { body } from 'express-validator';
import { authMiddleware } from '../middleware';

export const todoRouter = express.Router();

todoRouter.use(authMiddleware);

todoRouter.post(
  '/',
  [
    body('title')
      .notEmpty()
      .withMessage('Title is required'),
    body('description')
      .notEmpty()
      .withMessage('Description is required'),
    body('priority')
      .isIn(['high', 'medium', 'low'])
      .withMessage('Invalid priority'),
    body('status')
      .isIn(['completed', 'pending'])
      .withMessage('Invalid status'),
  ],
  create
);

todoRouter.get('/', get);

todoRouter.get('/:id', getById);

todoRouter.put(
  '/:id',
  [
    body('title')
      .optional()
      .isLength({ min: 3 })
      .withMessage('Title must be at least 3 characters long'),
    body('description')
      .optional()
      .isLength({ min: 3 })
      .withMessage('Description must be at least 3 characters long'),
    body('priority')
      .optional()
      .isIn(['high', 'medium', 'low'])
      .withMessage('Invalid priority'),
    body('status')
      .optional()
      .isIn(['completed', 'pending'])
      .withMessage('Invalid status'),
  ],
  update
);

todoRouter.delete('/:id', remove);