import express from 'express';
import { get, getById, remove } from '../controllers/user';
import { authMiddleware } from '../middleware';

export const userRouter = express.Router();

userRouter.use(authMiddleware);

userRouter.get('/', get);

userRouter.get('/:id', getById);

userRouter.delete('/:id', remove);