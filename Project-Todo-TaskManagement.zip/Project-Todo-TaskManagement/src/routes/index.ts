import express from 'express';
import { authRouter } from './auth';
import { todoRouter } from './todo';
import { userRouter } from './user';

export const modules = (app: express.Application) => {
  app.use('/auth', authRouter);
  app.use('/todos', todoRouter);
  app.use('/users', userRouter);
};