import { hashPassword, comparePassword } from '../utils/password';
import {
  createUser as createUserModel,
  getUserByUsername,
  getUserByEmail,
} from '../models/user';
import { generateToken } from '../utils/jwt';

export const createUser = async (
  username: string,
  email: string,
  password: string
) => {
  const hashedPassword = await hashPassword(password);
  const existingUser = await getUserByUsername(username);
  if (existingUser) {
    throw new Error('Username already exists');
  }
  const existingEmail = await getUserByEmail(email);
  if (existingEmail) {
    throw new Error('Email already exists');
  }
  const user = await createUserModel(username, email, hashedPassword);
  return user;
};

export const loginUser = async (username: string, password: string) => {
  const user = await getUserByUsername(username);
  if (!user) {
    throw new Error('User not found');
  }
  const isPasswordValid = await comparePassword(password, user.password);
  if (!isPasswordValid) {
    throw new Error('Invalid credentials');
  }
  const token = generateToken(user);
  return { ...user, token };
};