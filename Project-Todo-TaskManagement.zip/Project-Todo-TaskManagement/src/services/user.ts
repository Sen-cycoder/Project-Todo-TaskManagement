import {
    getUsers as getUserModel,
    getUserById as getUserByIdModel,
    deleteUserById as deleteUserByIdModel,
  } from '../models/user';
  
  export const getUsers = async () => {
    const users = await getUserModel();
    return users;
  };
  
  export const getUser = async (id: number) => {
    const user = await getUserByIdModel(id);
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  };
  
  export const deleteUser = async (id: number) => {
    const user = await deleteUserByIdModel(id);
    if (!user) {
      throw new Error('User not found');
    }
  };