import {
    createTodo as createTodoModel,
    getTodosByUserId,
    getTodoById,
    updateTodoById,
    deleteTodoById,
  } from '../models/todo';
  
  export const createTodo = async (
    title: string,
    description: string,
    priority: string,
    status: string,
    userId: number
  ) => {
    const todo = await createTodoModel(
      title,
      description,
      priority,
      status,
      userId
    );
    return todo;
  };
  
  export const getTodos = async (userId: number) => {
    const todos = await getTodosByUserId(userId);
    return todos;
  };
  
  export const getTodo = async (id: number, userId: number) => {
    const todo = await getTodoById(id);
    if (!todo) {
      throw new Error('Todo not found');
    }
    if (todo.userId !== userId) {
      throw new Error('Unauthorized');
    }
    return todo;
  };
  
  export const updateTodo = async (
    id: number,
    title: string,
    description: string,
    priority: string,
    status: string,
    userId: number
  ) => {
    const todo = await updateTodoById(
      id,
      title,
      description,
      priority,
      status,
      userId
    );
    if (!todo) {
      throw new Error('Todo not found');
    }
    return todo;
  };
  
  export const deleteTodo = async (id: number, userId: number) => {
    const todo = await deleteTodoById(id);
    if (!todo) {
      throw new Error('Todo not found');
    }
    if (todo.userId !== userId) {
      throw new Error('Unauthorized');
    }
  };