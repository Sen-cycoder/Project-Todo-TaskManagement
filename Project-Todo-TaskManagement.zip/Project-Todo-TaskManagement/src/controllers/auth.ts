import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import {
  createUser,
  loginUser,
} from '../services/auth';

export const register = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, email, password } = req.body;
  try {
    const user = await createUser(username, email, password);
    return res.status(201).json(user);
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};

export const login = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, password } = req.body;
  try {
    const user = await loginUser(username, password);
    return res.status(200).json(user);
  } catch (error: any) {
    return res.status(401).json({ message: error.message });
  }
};