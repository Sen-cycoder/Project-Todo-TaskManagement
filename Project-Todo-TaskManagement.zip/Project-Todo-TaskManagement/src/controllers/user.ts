import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { getUsers, getUser, deleteUser } from '../services/user';

export const get = async (req: Request, res: Response) => {
  try {
    const users = await getUsers();
    return res.status(200).json(users);
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};

export const getById = async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    const user = await getUser(parseInt(id, 10));
    return res.status(200).json(user);
  } catch (error: any) {
    return res.status(404).json({ message: error.message });
  }
};

export const remove = async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    await deleteUser(parseInt(id, 10));
    return res.status(204).send();
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};