import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import {
  createTodo,
  getTodos,
  getTodo,
  updateTodo,
  deleteTodo,
} from '../services/todo';

export const create = async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { title, description, priority, status } = req.body;
  try {
    const todo = await createTodo(
      title,
      description,
      priority,
      status,
      req.user!.id
    );
    return res.status(201).json(todo);
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};

export const get = async (req: Request, res: Response) => {
  try {
    const todos = await getTodos(req.user!.id);
    return res.status(200).json(todos);
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};

export const getById = async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    const todo = await getTodo(parseInt(id, 10), req.user!.id);
    return res.status(200).json(todo);
  } catch (error: any) {
    return res.status(404).json({ message: error.message });
  }
};

export const update = async (req: Request, res: Response) => {
  const { id } = req.params;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { title, description, priority, status } = req.body;
  try {
    const todo = await updateTodo(
      parseInt(id, 10),
      title,
      description,
      priority,
      status,
      req.user!.id
    );
    return res.status(200).json(todo);
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};

export const remove = async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    await deleteTodo(parseInt(id, 10), req.user!.id);
    return res.status(204).send();
  } catch (error: any) {
    return res.status(500).json({ message: error.message });
  }
};